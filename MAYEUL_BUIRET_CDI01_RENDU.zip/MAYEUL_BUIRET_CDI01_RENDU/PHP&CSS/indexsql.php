<?php

try {

    $database = new PDO('mysql:host=localhost;dbname=Twitter','root','');

} catch(PDOException $e) {
    die('Site Indisponible');
}

//Recupere toutes les données :
//SELECT * FROM user

// récupere que les colonnes nom et mail

//ORDER BY : tri ASC ou DESC
//LIMIT : limite le nombre de résultat
//WHERE : Met une condition



$requeteUser = $database->prepare('SELECT id, nom, email FROM user ORDER BY createdAt DESC LIMIT 2');
$requeteUser->execute();
$users = $requeteUser->fetchAll(PDO::FETCH_ASSOC);



if($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form'] == 'ajoutUser'){
    if ($_POST['nom'] != '' && $_POST['email'] != ''){
        $nouvelUser =[
            'nom' => $_POST['nom'],
            'email'=> $_POST['email'],
            'password'=>$_POST['password']
        ];

        $requeteUser = $database -> prepare("INSERT INTO user (nom, email, password) VALUES (:nom, :email, :password)");
        if ($requeteUser -> execute($nouvelUser)){
            echo "User bien ajouté";
        }else{
            echo "Erreur lors de l'ajout";
        }


    } else {
        echo "Formulaire incomplet";
    }
}

$requeteTweet = $database->prepare('SELECT tweet, date_post, user_id FROM tweets ORDER BY date_post ');
    $requeteTweet->execute();
    $tweets = $requeteTweet->fetchAll(PDO::FETCH_ASSOC);

if($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form'] == 'nouveauTweet'){
    if ($_POST['tweet'] != ''){
        $newTweet =[
            'tweet' => $_POST['tweet'],
        ];

        $requeteTweet = $database -> prepare("INSERT INTO tweets (tweet) VALUES (:tweet)");
        if ($requeteTweet -> execute($newTweet)){
            echo "Nouveau Tweet bien envoyé";
        }else{
            echo "Tweet trop long";
        }


    } else {
        echo "Tweet incomplet";
    }
}





$allusers = $database->query('SELECT * FROM tweets ORDER BY id DESC');
    if(isset($_GET['s']) && !empty($_GET['s'])){
        $recherche = htmlspecialchars($_GET['s']);
        $allusers = $database->query('SELECT tweet FROM tweets WHERE tweet LIKE "%'.$recherche.'%" ORDER BY id DESC');
    }
?>

    


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Twitter</title>
</head>
<body>
    <a href="twitter.php"><button type="button" class='btn-acc'>Accueil</button></a>

</body>
</html>

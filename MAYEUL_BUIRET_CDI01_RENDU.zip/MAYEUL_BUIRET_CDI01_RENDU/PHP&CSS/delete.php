<?php
require 'indexsql.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form'] == 'supprimer'){

    $userASupprimer = [
        'id' => $_POST['suppr']
    ];

    $requeteUser = $database->prepare('DELETE FROM user WHERE id = :id');
    $requeteUser->execute($userASupprimer);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form'] == 'supprimerTweet'){

    $tweetASupprimer = [
        'id' => $_POST['supprTweet']
    ];

    $requeteTweet = $database->prepare('DELETE FROM tweets WHERE id = :id');
    $requeteTweet->execute($tweetASupprimer);
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Twitter</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <h1>Twitter Bis</h1>
    
    <?php require 'indexsql.php';?>
    <h2> Utilisateurs Actifs</h2>
    <?php foreach($users as $user) : ?>

        <form class='name-display'action='delete.php' method="POST">    
            <input type="hidden" name="form" value="supprimer">
            <input type="hidden" name="suppr" value="<?php echo $user['id']; ?>">
            <?php echo '<li>' .$user['nom'].' - '.$user['email'].'</li>'; ?>
            <button type="submit">Supprimer l'utilisateur</button>
        </form>
    
    <?php endforeach; ?>


    <div class="trait"></div>


    <div class="ajout-user-div1">
        <div class="ajout-user-div2">
        <form action="indexsql.php" method="POST">

            <input type="hidden" name="form" value="ajoutUser">

            <label for="nom">Nom</label>
            <input type="text" name="nom" id="nom">

            <label for="email">Email</label>
            <input type="text" name="email" id="email">

            <label for="password">Mot de Passe</label>
            <input type="password" name="password" id="password">
        </div>
        <div class="ajout-user-">
            <button type="submit">Envoyer</button>
        </form>
        </div>
    </div>

    <div class="trait"></div>

    <h2>Nouveau Tweet<h2>
        <form class="nv-tweet-div" action="indexsql.php" method="POST">
            <input type="hidden" name="form" value="nouveauTweet">
            
            <textarea name="tweet" id="tweet" cols="30" rows="10"></textarea>
            
            
            <button type="submit">Envoyer</button>

        </form>

    <div class="trait"></div>


    <form class='search' method="get" action="">
        <input type="search" name="s" placeholder="Rechercher un Tweet">
        <input id="send" type="submit" name="envoyer">
    </form>

    <?php
        if($allusers->rowCount() > 0){
            while($user = $allusers->fetch()){
                ?>
                <p id='tweet-post'><?= $user['tweet']; ?></p>
                <?php
                // Afficher la date correspondante à chaque tweet
                foreach($tweets as $tweet) {
                    if($tweet['tweet'] === $user['tweet']) {
                        ?>
                        <p id='tweet-date'><?= $tweet['date_post']; ?></p>
                        <form action='delete.php' method="POST">    
                            <input type="hidden" name="form" value="supprimerTweet">
                            <input type="hidden" name="supprTweet" value=" <?php echo $tweet['date_post']; ?> ">
                            <button id="delt-tweet" type="submit">Supprimer le Tweet</button>
                        </form>
                        <?php
                        break; 
                    }
                }
            }
        } else {
            ?>
            <p>Aucun Tweet trouvé</p>
            <?php
        }
    ?>
    
    <?php

        
    

    ?>



</body>
</html>